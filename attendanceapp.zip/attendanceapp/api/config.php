<?php

// Update these values to your cPanel MySQL credentials.
define('DB_HOST', 'localhost');
define('DB_NAME', 'attendancedb');
define('DB_USER', 'attendancedb');
define('DB_PASS', 'KingBaye@0151989');
define('DB_CHARSET', 'utf8mb4');